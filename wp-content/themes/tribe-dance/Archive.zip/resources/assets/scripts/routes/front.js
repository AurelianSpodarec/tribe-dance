export default {
  init() {
    // JavaScript to be fired on the home page

      // var siteHeader = document.querySelector('.js-mainHeader'),
      //     siteHeaderHeight = siteHeader.offsetHeight,
      //     prevScroll = 0;
      // console.log('SDds', window.scrollY)
      //
      // function stickyNav() {
      //     if (window.scrollY >= siteHeaderHeight) {
      //         siteHeader.classList.add('is-sticky');
      //     } else{
      //         siteHeader.classList.remove('is-sticky');
      //     }
      // }
      //
      // function showNav() {
      //     var currentScroll = window.pageYOffset;
      //
      //     if(currentScroll < prevScroll) {
      //         siteHeader.classList.add('sticky-show');
      //     } else {
      //         siteHeader.classList.remove('sticky-show');
      //     }
      //     prevScroll = currentScroll;
      // }
      //
      // window.addEventListener('scroll', showNav);
      // window.addEventListener('scroll', stickyNav);
      //



  },
  finalize() {
    // JavaScript to be fired on the home page, after the init JS
  },
};
