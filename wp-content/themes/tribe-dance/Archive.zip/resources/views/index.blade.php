@extends('layouts.app')

@section('content')
     index
@endsection
