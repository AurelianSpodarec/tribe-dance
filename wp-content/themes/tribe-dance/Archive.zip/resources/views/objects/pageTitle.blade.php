<h2 class="font-bold text-2xl tracking-three pb-6 uppercase">
    {{ $title }}
    <div class="bg-gray-200 my-3 mx-auto w-full" style="height: 1px;"></div>
</h2>
