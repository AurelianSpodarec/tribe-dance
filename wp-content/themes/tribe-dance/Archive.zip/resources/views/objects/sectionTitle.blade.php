<h2 class="text-center font-bold tracking-three pb-6  uppercase">
    {{ $title }}
    <div class="bg-accent my-3 mx-auto" style="width: 45px; height: 3px;"></div>
</h2>
